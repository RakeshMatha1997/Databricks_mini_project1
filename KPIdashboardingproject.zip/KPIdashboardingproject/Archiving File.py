# Databricks notebook source
# Move first file starting with prefix from /mnt/landing to /mnt/archive
def move_file(prefix):
    # List all files in the landing folder
    files = dbutils.fs.ls("/mnt/landing")
    
    # Filter files that start with the given prefix
    matching_files = [f.name for f in files if f.name.startswith(prefix)]
    
    if matching_files:
        file_name = matching_files[0]
        file_loc = f"dbfs:/mnt/landing/{file_name}"
        target_loc = f"dbfs:/mnt/archive/{file_name}"
        dbutils.fs.mv(file_loc, target_loc)
        print(f"Moved {file_loc} → {target_loc}")
    else:
        print(f"No file found starting with {prefix}")

# Move SourceA file
move_file("SourceA")

# Move SourceB file
move_file("SourceB")

# Move SourceC file
move_file("SourceC")
