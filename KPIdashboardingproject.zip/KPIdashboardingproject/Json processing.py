# Databricks notebook source
df=spark.read.options(header='True',inferSchema='True').json('/mnt/landing/SourceB*.json')

# COMMAND ----------

dfFlat = df.select(
                        "Employee_id"
                        ,"Age"
                        ,"Customer.First_Name"
                        ,"Customer.Last_Name"
                        ,"Gender"
                        ,"Salary"
                        ,"Date_Of_Birth"
                        ,"Age"
                        ,"Country"
                        ,"Department_id"
                        ,"Date_Of_Joining"
                        ,"Manager_id"
                        ,"Currency"
                        ,"End_Date"
                      )

# COMMAND ----------

dfFlat.createOrReplaceTempView("Emp")

# COMMAND ----------

dfCast = spark.sql("select cast(Employee_id as int),cast(Age as int),First_Name,Last_Name,Gender,cast(Salary as int),cast(Date_Of_Birth as date),Country,cast(Department_id as int),cast(Date_Of_Joining as date),cast(Manager_id as int),Currency,cast(End_Date as date) from EMP")

# COMMAND ----------

# Load the driver class (optional in PySpark on Databricks, driver is auto-handled in most cases)
driver_class = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# Fetch credentials from Databricks secret scope
jdbc_username = dbutils.secrets.get(scope="jdbc", key="username")
jdbc_password = dbutils.secrets.get(scope="jdbc", key="password")

# JDBC connection details
jdbc_hostname = "kpidashboardingserver.database.windows.net"
jdbc_port = 1433
jdbc_database = "sqlkpidashboarding"

# Construct JDBC URL
jdbc_url = f"jdbc:sqlserver://{jdbc_hostname}:{jdbc_port};database={jdbc_database}"

# Connection properties
connection_properties = {
    "user": jdbc_username,
    "password": jdbc_password,
    "driver": driver_class
}

# COMMAND ----------

dfCast.printSchema()

# COMMAND ----------

dfCast.write.mode("Append").jdbc(url=jdbc_url, table="datawarehousedb.Employee", properties=connection_properties)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE or Replace TABLE datawarehousedb.Employee_json_processing (
# MAGIC     Employee_id       INT,
# MAGIC     Age               INT,
# MAGIC     First_Name        VARCHAR(100),
# MAGIC     Last_Name         VARCHAR(100),
# MAGIC     Gender            VARCHAR(10),
# MAGIC     Salary            INT,
# MAGIC     Date_Of_Birth     DATE,
# MAGIC     Country           VARCHAR(100),
# MAGIC     Department_id     INT,
# MAGIC     Date_Of_Joining   DATE,
# MAGIC     Manager_id        INT,
# MAGIC     Currency          VARCHAR(10),
# MAGIC     End_Date          DATE
# MAGIC );
# MAGIC

# COMMAND ----------

dfCast.write.mode("Append").format("delta").saveAsTable("datawarehousedb.Employee_json_processing")
