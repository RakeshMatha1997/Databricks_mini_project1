// Databricks notebook source
// MAGIC %python
// MAGIC # List all mount points
// MAGIC mounts = [x.mountPoint for x in dbutils.fs.mounts()]
// MAGIC
// MAGIC mount_path = "/mnt/landing"
// MAGIC
// MAGIC if mount_path in mounts:
// MAGIC     print(f"Unmounting {mount_path} ...")
// MAGIC     dbutils.fs.unmount(mount_path)
// MAGIC     print("Unmount complete.")
// MAGIC else:
// MAGIC     print(f"{mount_path} is not mounted. Skipping unmount.")
// MAGIC

// COMMAND ----------

// MAGIC %python
// MAGIC # List all mount points
// MAGIC mounts = [x.mountPoint for x in dbutils.fs.mounts()]
// MAGIC
// MAGIC mount_path = "/mnt/archive"
// MAGIC
// MAGIC if mount_path in mounts:
// MAGIC     print(f"Unmounting {mount_path} ...")
// MAGIC     dbutils.fs.unmount(mount_path)
// MAGIC     print("Unmount complete.")
// MAGIC else:
// MAGIC     print(f"{mount_path} is not mounted. Skipping unmount.")
// MAGIC

// COMMAND ----------

val containerName = "landing"
val storageAccountName = "sadashboardingproject"
val sas = "sv=2024-11-04&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2026-01-01T15:13:55Z&st=2025-07-02T07:13:55Z&spr=https&sig=3HhMO2rB%2FDBffcBna2tpiZT%2BwpCdfVvs3zujixnBEF8%3D"
val url = "wasbs://" + containerName + "@" + storageAccountName + ".blob.core.windows.net/"
var config = "fs.azure.sas." + containerName + "." + storageAccountName + ".blob.core.windows.net"

// COMMAND ----------

// COMMAND ----------

dbutils.fs.mount(
source = url,
mountPoint = "/mnt/landing",
extraConfigs = Map(config -> sas))

// COMMAND ----------

val containerName = "archive"
val storageAccountName = "sadashboardingproject"
val sas = "sv=2024-11-04&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2026-01-01T15:13:55Z&st=2025-07-02T07:13:55Z&spr=https&sig=3HhMO2rB%2FDBffcBna2tpiZT%2BwpCdfVvs3zujixnBEF8%3D"
val url = "wasbs://" + containerName + "@" + storageAccountName + ".blob.core.windows.net/"
var config = "fs.azure.sas." + containerName + "." + storageAccountName + ".blob.core.windows.net"

// COMMAND ----------

// COMMAND ----------

dbutils.fs.mount(
source = url,
mountPoint = "/mnt/archive",
extraConfigs = Map(config -> sas))