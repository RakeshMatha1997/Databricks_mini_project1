# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# Define schema
depSchema = StructType([
    StructField("Department_id", IntegerType(), True),
    StructField("Name", StringType(), True)
])

# Read CSV
df = spark.read \
    .option("header", "true") \
    .schema(depSchema) \
    .csv("/mnt/landing/Department.csv")



# COMMAND ----------

df.write.mode("Append").format("delta").saveAsTable("datawarehousedb.department")  